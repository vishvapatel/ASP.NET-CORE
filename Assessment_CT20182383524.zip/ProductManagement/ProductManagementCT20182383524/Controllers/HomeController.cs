﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Extensions.Logging;
using ProductManagementCT20182383524.Data;
using ProductManagementCT20182383524.Models;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace ProductManagementCT20182383524.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ProductsContext _context;

        public HomeController(ILogger<HomeController> logger, ProductsContext context)
        {
            _logger = logger;
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            return View(await _context.products.ToListAsync());
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Search(string productCategory)
        {
            if (!string.IsNullOrEmpty(productCategory))
            {
                if (_context.products.Any(p => p.category == productCategory))
                {
                    var filterByCategoryQuery = _context.products.Where(p => p.category == productCategory);
                    return View(await filterByCategoryQuery.ToListAsync());
                }
                else
                {
                    ViewData["CategoryNotExist"] = 1;
                    return RedirectToAction("Index");
                }
            }
            else
            {
                return RedirectToAction("Index");
            }
        }


        [HttpGet]
        public IActionResult AddProduct()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddProduct([Bind("Id, productId, category, quantity, price, productName")] Product product)
        {
            if (ModelState.IsValid)
            {
                if (_context.products.Any(p => p.productName == product.productName))
                {
                    ViewData["ProductExists"] = 1;
                    return View();
                }
                else if(product.category == "Fruits" || product.category == "Vegetable")
                {
                    if(product.price > 0 && product.price <= 500)
                    {
                        _context.products.Add(product);
                        await _context.SaveChangesAsync();
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        ViewData["InvalidPrice"] = 1;
                        return View();
                    }
                }
                else
                {
                    ViewData["InvalidCategory"] = 1;
                    return View();
                }
            }
            else{

                return View();
            }
        }






        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
