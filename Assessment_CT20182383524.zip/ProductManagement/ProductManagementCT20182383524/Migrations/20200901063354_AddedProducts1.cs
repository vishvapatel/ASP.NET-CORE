﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ProductManagementCT20182383524.Migrations
{
    public partial class AddedProducts1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
