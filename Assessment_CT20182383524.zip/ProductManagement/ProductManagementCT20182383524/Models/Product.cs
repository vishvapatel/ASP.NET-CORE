﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ProductManagementCT20182383524.Models
{
    public class Product
    {
        public int id { get; set; }
        
        [Required]
        public int productId { get; set; }

        [Required]
        public string productName { get; set; }

        [Required]
        public string category { get; set; }

        [Required]
        public int quantity { get; set; }

        [Required]
        public double price { get; set; }

    }
}
