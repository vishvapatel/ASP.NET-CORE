﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Security.Principal;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.AspNetCore.Razor.Language.Extensions;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using RetailBanking.Data;
using RetailBanking.Models;
using Rotativa.AspNetCore;

namespace RetailBanking.Controllers
{
    public class AccountsController : Controller
    {
        private readonly FedchoiceContext _context; //creating context variable of database type.
        private static Random _rand = new Random(); //Declaring a object of Random class to generate 9 digit accId.
        private static Account a = null;
        private static List<Transactions> transactions = new List<Transactions>();


        public AccountsController(FedchoiceContext context)
        {
            _context = context; //Initializing Context object, this wil be used to access the data tables in the databse FedchoiceContext -1
        }



        //Get: Accounts/AccountStatus
        public async Task<IActionResult> Status()
        {
            try
            {

                var Employee = JsonConvert.DeserializeObject<SessionVariables>(HttpContext.Session.GetString("LoggedinEmployee"));
                ViewData["Login"] = 1;
                return View(await _context.accounts.ToListAsync()); //returning the whole data from the accounts table in form of the list 
            }
            catch (Exception e)
            {
                var message = e;
                return RedirectToAction("Login", "Login");
            }
            
        }



        //Get: Accounts/Create
        public IActionResult Create()
        {
            try
            {

                var Employee = JsonConvert.DeserializeObject<SessionVariables>(HttpContext.Session.GetString("LoggedinEmployee"));
                ViewData["Login"] = 1;
                return View();
            }
            catch (Exception e)
            {
                var message = e;
                return RedirectToAction("Login", "Login");
            }
        }



        //Post: Accounts/Create
        [HttpPost] //This function will only be called when the create form is submitted.
        [ValidateAntiForgeryToken] //asp-form will hash the form details. thus to validate it we use this dataannotation.
        public async Task<IActionResult> Create([Bind("Id,CustomerId,AccountType,balance")] Account account)
        {
            ViewData["Login"] = 1;
            if (account != null)
            {
                if (account.CustomerId.ToString().Length != 9)
                {
                    return View();
                }
                else
                {
                    
                    //Checking if Customer exists or not
                    var customer = _context.customers.Any(c => c.CustomerId == account.CustomerId);

                    int accId = _rand.Next(100000000, 999999999); //Generating Random  9 digit account id.
                    var GetAccIdQuery = from a in _context.accounts
                                        select new { accid = a.AccountId }; //Getting a IQueryable list of all the account Id's in the database


                    //Checking if accId already exists
                    foreach (var a in GetAccIdQuery)
                    {
                        if (accId == a.accid)
                        {
                            accId = _rand.Next(100000000, 999999999); //If accId already exists generate again.
                        }
                    }
                    
                    
                    //If customer exists
                    if (customer)
                    {

                        // Creating an object of Account Model to add in datatable accounts
                        var newAccount = new Account
                        {
                            CustomerId = account.CustomerId,
                            AccountId = accId,
                            balance = account.balance,
                            status = "Active",
                            Message = "Account created sucessfully",
                            LastUpdated = DateTime.Now,
                            AccountType = account.AccountType
                        };

                        _context.Add(newAccount); //Adding the data to the table
                        await _context.SaveChangesAsync(); //saving the changes to the database.

                        TempData["Newaccount"] = "Account created successfully :)"; //Passing a temperory acknowledgement data to home controller to display successcul transaction 
                        return RedirectToAction("Index", "Home"); //redirecting to Home page
                    }
                    
                    
                    // if customer does not exist 
                    else
                    {
                        return RedirectToAction("Create","Customer"); //redrectingto create customer screen : to create customer 
                    }
                }
            }
            return View(account); //if the form returns null then return the same view again.
                
        }
        
        

        //Get: Accounts/Delete

        public IActionResult Delete()
        {
            try
            {
                var Employee = JsonConvert.DeserializeObject<SessionVariables>(HttpContext.Session.GetString("LoggedinEmployee"));
                ViewData["Login"] = 1;
                return View(); 
            }
            catch (Exception e)
            {
                var message = e;
                return RedirectToAction("Login", "Login");
            }
        }



        //Post: Accouts/Delete

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete([Bind("Id,AccountId,AccountType")]Account account)
        {
            if (account != null)
            {
                if (account.AccountId.ToString().Length != 9)
                {
                    return View(account);
                }
                else
                {
                    //Check Account Id exists or not
                    var ac = _context.accounts.Any(a => a.AccountId == account.AccountId);
                    if (!ac)
                    {
                        TempData["NoAccount"] = true;
                        return RedirectToAction("Create");
                    }
                    //Account exists 
                    else
                    {
                        var acc = _context.accounts
                            .Where(a => a.AccountId == account.AccountId && a.AccountType == account.AccountType)
                            .Take(1);
                        Account ToDeleteAccount = null;
                        foreach (var a in acc)
                        {
                            if (a != null)
                            {
                                ToDeleteAccount = a; //Transferring the data of model account to the account
                            }
                        }
                        if (ToDeleteAccount != null)
                        {
                            _context.accounts.Remove(ToDeleteAccount); //Removing the account 
                            await _context.SaveChangesAsync(); //Saving the database
                            TempData["DeleteSuccess"] = "Account Deletion Successfull :)"; //Delete acknowledgement message
                            return RedirectToAction("Index", "Home"); //Redirect to action Index
                        }
                    }
                }
            }
            return View(account);       
        }


        //GET: Accounts/Details

        public async Task<IActionResult> Details()
        {
            if (TempData["Details"] == null)
            {
                return NotFound();
            }
            else
            {
                ViewData["Login"] = 1;
                var AccDetails = _context.accounts.Where(a => a.AccountId == Convert.ToInt32(TempData["Details"])); //Getting the details of the account from the database
                return View(await AccDetails.ToListAsync()); //Passing the converte IQueryable into IEnumerable to the view 
            }
        }


        //GET: Accounts/Search
        public IActionResult Search()
        {
            try
            {

                var Employee = JsonConvert.DeserializeObject<SessionVariables>(HttpContext.Session.GetString("LoggedinEmployee"));
                ViewData["Login"] = 1;
                return View(); 
            }
            catch (Exception e)
            {
                var message = e;
                return RedirectToAction("Login", "Login");
            }
        }

        //POST: Accounts/Search
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Search([Bind("Id, AccountId")] Account account)
        {
            if(account != null)
            {
                if(account.AccountId.ToString().Length != 9) //validaitng the length of the account Id
                {
                    return View(account); //returning the view 
                }
                else
                {
                    var accExists = _context.accounts.Any(a => a.AccountId == account.AccountId); //Checking if the account Id exists
                    if (accExists)
                    {
                        TempData["Details"] = account.AccountId; //Passing it to the TempData so Details action can access it and display the details.
                        return RedirectToAction("Details"); //Deatils of the account.
                    }
                    else
                    {
                        TempData["NoAccount"] = true; //Passing Data in TempData dictionary if account not found. 
                        return RedirectToAction("Create"); //redirect to create action 
                    }
                }
            }
            return View(account); //If form returns null then return view.
        }

        //-----------------------------------------------------------------TRANSACTIONSCONTROL-------------------------------------------------------


        public int GetTransactionId()
        {
            var t_id = _rand.Next(100000000, 999999999);

            //Checking for existing t-ids
            var TidQuery = from t in _context.transactions
                           select new { Id = t.TransactionId };
            foreach(var t in TidQuery)
            {
                t_id = t.Id == t_id ? _rand.Next(100000000, 999999999) : t_id;
            }
            return t_id;
        }




        //GET: Accounts/Deposit
        public IActionResult Deposit()
        {
            try
            {
                var Employee = JsonConvert.DeserializeObject<SessionVariables>(HttpContext.Session.GetString("LoggedinEmployee"));
                ViewData["Login"] = 1;
                return View();
            }
            catch (Exception e)
            {
                var message = e; 
                return RedirectToAction("Login", "Login");
            }
        }

        //POST:  Accounts/Deposit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Deposit([Bind("Id, AccountId")] Account account) 
        {
            if(account.AccountId.ToString().Length != 9)
            {
                return View();
            }
            else
            {
                var acc = await _context.accounts.FirstOrDefaultAsync(a => a.AccountId == account.AccountId);
                if(acc != null)
                {
                    a = acc;
                    return RedirectToAction(nameof(DepositConfirm));
                }
                else
                {
                    TempData["NoAccount"] = true; //Passing Data in TempData dictionary if account not found. 
                    return RedirectToAction("Create"); //redirect to create action 
                }
            }
        }

        //GET: Accounts/DepositConfirm
        public IActionResult DepositConfirm()
        {
            ViewData["Login"] = 1;
            return View(a);
        }

        //POST: Accounts/DepositConfirm
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DepositConfirm(int deposit, [Bind("Id, CustomerId, AccountId, balance, AccountType")] Account account)
        {


            //Saving into accounts table
            var adddeposit = _context.accounts.Find(account.Id);
            adddeposit.balance += deposit;
            adddeposit.Message = "Amount Deposited Succesfully";
            adddeposit.status = "Active";
            adddeposit.LastUpdated = DateTime.Now;
            _context.SaveChanges();

            //Generating new transaction and adding into transactions table
            var Transaction = new Transactions()
            {
                TransactionId = GetTransactionId(),
                SrcAccountId = account.AccountId,
                TgtAccountId = account.AccountId,
                Amount = deposit,
                Discription = "Deposit",
                Date = DateTime.Now.Date
            };
            _context.Add(Transaction);
            await _context.SaveChangesAsync();

            TempData["DepositSuccess"] = "Deposit Succesfull :)";
            return RedirectToAction("Index", "Home");
        }

        //------Withdraw------------------------------------------

        //Get: Accounts/withdraw
        public IActionResult Withdraw()
        {
            try
            {
                var Employee = JsonConvert.DeserializeObject<SessionVariables>(HttpContext.Session.GetString("LoggedinEmployee"));
                ViewData["Login"] = 1;
                return View();
            }
            catch (Exception e)
            {
                var message = e;
                return RedirectToAction("Login", "Login");
            }
        }

        //POST:  Accounts/Withdraw
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Withdraw([Bind("Id, AccountId")] Account account)
        {
            if (account.AccountId.ToString().Length != 9)
            {
                return View();
            }
            else
            {
                var acc = await _context.accounts.FirstOrDefaultAsync(a => a.AccountId == account.AccountId);
                if (acc != null)
                {
                    a = acc;
                    return RedirectToAction(nameof(WithdrawConfirm));
                }
                else
                {
                    TempData["NoAccount"] = true; //Passing Data in TempData dictionary if account not found. 
                    return RedirectToAction("Create"); //redirect to create action 
                }
            }
        }

        //GET: Accounts/WithdrawConfirm
        public IActionResult WithdrawConfirm()
        {
            ViewData["Login"] = 1;
            return View(a);
        }

        //POST: Accounts/WithdrawConfirm
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> WithdrawConfirm(int withdraw, [Bind("Id, CustomerId, AccountId, balance, AccountType")] Account account)
        {
            if(withdraw > account.balance)
            {
                TempData["Lowbalance"] = "Withdraw unsuccessful due to low balance";
                return View();
            }
            var addwithdraw = _context.accounts.Find(account.Id);
            addwithdraw.balance -= withdraw;
            addwithdraw.Message = "Amount Withdrawn successfully";
            addwithdraw.LastUpdated = DateTime.Now;
            _context.SaveChanges();


            var Transaction = new Transactions()
            {
                TransactionId = GetTransactionId(),
                SrcAccountId = account.AccountId,
                TgtAccountId = account.AccountId,
                Amount = withdraw,
                Discription = "Withdraw",
                Date = DateTime.Now.Date
            };

            _context.Add(Transaction);
            await _context.SaveChangesAsync();
            TempData["WithdrawSuccess"] = "Withdraw Succesfull :)";
            return RedirectToAction("Index", "Home");
        }

        //Transfer-----------------------------------
        //GET: Accounts/Transfer
        public IActionResult Transfer()
        {
            try
            {
                var Employee = JsonConvert.DeserializeObject<SessionVariables>(HttpContext.Session.GetString("LoggedinEmployee"));
                ViewData["Login"] = 1;
                return View();
            }
            catch (Exception e)
            {
                var message = e;
                return RedirectToAction("Login", "Login");
            }

        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Transfer(int srcacc, int tgtacc,int transfer, [Bind("Id,CustomerId")] Account account)
        {
            if(srcacc.ToString().Length !=9 || tgtacc.ToString().Length != 9 || account.CustomerId.ToString().Length !=9)
            {
                TempData["InvalidId"] = "Account Id and Customer Id should be of 9 digits";
                return View();
            }
            else
            {
                //check for source account
                var sacc = await _context.accounts.FirstOrDefaultAsync(a => a.CustomerId == account.CustomerId && a.AccountId == srcacc);
                var tacc = await _context.accounts.FirstOrDefaultAsync(a => a.AccountId == tgtacc);
                if (sacc != null && tacc != null)
                {
                    if(sacc.balance < transfer)
                    {
                        TempData["Lowbalance"] = "Transfer unsuccessful due to low balance";
                        return View();
                    }
                    else
                    {
                        //updating the source account
                        var sourceacc = _context.accounts.Find(sacc.Id);
                        sourceacc.balance -= transfer;
                        sourceacc.Message = "Amount Transferred successfully";
                        sourceacc.status = "Active";
                        _context.SaveChanges();

                        //Updating the target account
                        var targetacc = _context.accounts.Find(tacc.Id);
                        targetacc.balance += transfer;
                        targetacc.Message = "Amount Received Successfully";
                        targetacc.status = "Active";
                        _context.SaveChanges();

                        //Adding this transaction
                        var Transaction = new Transactions()
                        {
                            TransactionId = GetTransactionId(),
                            SrcAccountId = sacc.AccountId,
                            TgtAccountId = tacc.AccountId,
                            Amount = transfer,
                            Discription = "Transfer",
                            Date = DateTime.Now.Date
                        };
                        _context.Add(Transaction);
                        await _context.SaveChangesAsync();
                        TempData["TransferSuccess"] = "Transfer Successfull :)";
                        return RedirectToAction("Index", "Home");
                    } 
                }
                else
                {
                    TempData["NoAccount"] = true; //Passing Data in TempData dictionary if account not found. 
                    return RedirectToAction("Create"); //redirect to create action 
                }
            }
        }

        //--------------------------------AccountStatement------------------------------------------------------------
        
        //GET: Accounts/AccountStatement
        public IActionResult AccountStatement()
        {
            try
            {
                var Employee = JsonConvert.DeserializeObject<SessionVariables>(HttpContext.Session.GetString("LoggedinEmployee"));
                ViewData["Login"] = 1;
                return View();
            }
            catch (Exception e)
            {
                var message = e;
                return RedirectToAction("Login", "Login");
            }
        }

        //POST: Accounts/AccountStatement
        [HttpPost]
        [validateAntiForgeryToken]
        public IActionResult AccountStatement(int accId, DateTime StrtDate,DateTime EndDate)
        {
            if(accId.ToString().Length != 9 || StrtDate > DateTime.Now.Date || EndDate > DateTime.Now.Date)
            {
                TempData["InvalidCredentials"] = "Account Id should be of 9 digits & Date can't be a future date";
                return View();
            }
            else
            {
                var Accexist = _context.accounts.Any(a => a.AccountId == accId);
                if (Accexist)
                {
                    var GetTransactionsQuery = _context.transactions.Where(t => t.SrcAccountId == accId && t.Date >= StrtDate && t.Date <= EndDate);
                    transactions = GetTransactionsQuery.ToList();
                    return RedirectToAction(nameof(Statement));
                }
                else
                {
                    TempData["NoAccount"] = true; //Passing Data in TempData dictionary if account not found. 
                    return RedirectToAction("Create"); //redirect to create action 
                }
            }
        }

        //GET: Accounts/Statement
        public IActionResult Statement()
        {
            return new ViewAsPdf(transactions);
        }
    }
}
