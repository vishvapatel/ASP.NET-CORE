﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.TagHelpers;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using RetailBanking.Data;
using RetailBanking.Models;

namespace RetailBanking.Controllers
{
    public class CustomerController : Controller
    {
        private readonly FedchoiceContext _context;
        private Random _rand = new Random();
        private static Customer custom = null;

        public CustomerController(FedchoiceContext context)
        {
            _context = context; //Initializing a database context object
        }


        //-----------------------------------------------------------------------------------------------
        //GET: Customer/Status
        public async Task<IActionResult> Status()
        {
            try
            {

                var Employee = JsonConvert.DeserializeObject<SessionVariables>(HttpContext.Session.GetString("LoggedinEmployee"));
                ViewData["Login"] = 1;
                return View(await _context.customers.ToListAsync()); //passing the data from the table the view
            }
            catch (Exception e)
            {
                var message = e;
                return RedirectToAction("Login", "Login");
            }
           
        }



        //--------------------------------------------------------------------------------

        //GET: Customer/Status/Details

        public async Task<IActionResult> Details(int? Id)
        {
            ViewData["Login"] = 1;
            if (Id == null)
            {
                return View();
            }
           
            var Customer = await _context.customers
                .FirstOrDefaultAsync(I => I.CustomerId == Id);
                if (Customer == null)
                {
                return NotFound();
                }

            return View(Customer);
        }




        //-------------------------------------------------------------------------------------------------

        //GET: Customer/Search
        public IActionResult Search()
        {
            try
            {

                var Employee = JsonConvert.DeserializeObject<SessionVariables>(HttpContext.Session.GetString("LoggedinEmployee"));
                ViewData["Login"] = 1;
                return View(); //passing the data from the table the view
            }
            catch (Exception e)
            {
                var message = e;
                return RedirectToAction("Login", "Login");
            }
        }

        //POST: Customer/Search 
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Search([Bind("CustomerId,CustomerSSNId")] Customer customer)
        {
            if(customer.CustomerId == 0 && customer.CustomerSSNId == 0) //True if no value is entered
            {
                ViewData["NoEntry"] = "Any one field is mandatory";
                return View(customer);
            }
            var GetId = _context.customers
                .Any(c => c.CustomerId == customer.CustomerId || c.CustomerSSNId == customer.CustomerSSNId);
            if (GetId) 
            {
                TempData["CustomerId"] = customer.CustomerId; 
                TempData["CustomerSSNId"] = customer.CustomerSSNId;
                return RedirectToAction("SearchResult");
            }
            else
            {
                TempData["NoCustomer"] = true;
                return RedirectToAction("Create");
            }
        }


        //GET: Customer/Details
        public async Task<IActionResult> SearchResult()
        {
            ViewData["Login"] = 1;
            var customer = await _context.customers
                .FirstOrDefaultAsync(c => c.CustomerId == Convert.ToInt32(TempData["CustomerId"]) || c.CustomerSSNId == Convert.ToInt32(TempData["CustomerSSNId"]));
            return View(customer);
        }
       

        //------------------------------------------------------------------------------


        //GET: Customer/Create
        public IActionResult Create()
        {
            try
            {

                var Employee = JsonConvert.DeserializeObject<SessionVariables>(HttpContext.Session.GetString("LoggedinEmployee"));
                ViewData["Login"] = 1;
                return View(); //passing the data from the table the view
            }
            catch (Exception e)
            {
                var message = e;
                return RedirectToAction("Login", "Login");
            }
        }

        //POST: Customer/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id, CustomerId, CustomerSSNId,Name, Age, Address, State, City")] Customer customer)
        {
            if(customer.CustomerSSNId.ToString().Length != 9 || customer.Age > 120 || customer.Age == 0)
            {
                //TempData["InvalidId"] = "CustomerSSNId must be of 9 digits ";
                return View();
            } 
            //check if customer already exists
            var cust = _context.customers.Any(a => a.CustomerSSNId == customer.CustomerSSNId);
            if (cust)
            {
                TempData["CustomerExists"] = "Customer already exists :)";
                return View(customer);
            }
            else
            {
                int Id = _rand.Next(100000000, 999999999); //Generate a 9 digit customer Id
                //Getting all the customer Id's from the Customer table
                var GetIDQuery = from c in _context.customers
                                 select new { Id = c.CustomerId };

                //Checking for the duplication of the ID generated
                foreach (var c in GetIDQuery)
                {
                    if (c.Id == Id)
                    {
                        Id = _rand.Next(100000000, 999999999);
                    }
                }
                //Everything is a go, thus add new customer
                var NewCustomer = new Customer
                {
                    CustomerId = Id,
                    CustomerSSNId = customer.CustomerSSNId,
                    Age = customer.Age,
                    Name = customer.Name,
                    Address = customer.Address,
                    State = customer.State,
                    City = customer.City,
                    status = "Active",
                    Message = "Customer Created Successfully",
                    LastUpdated = DateTime.Now
                };
                _context.Add(NewCustomer);
                await _context.SaveChangesAsync();
                TempData["CustomerSuccess"] = "Customer Created Successfully :)";
                return RedirectToAction("Index", "Home");
            }
        }

        //------------------------------------------------------------------------------------------------------
        
        //GET: Customer/Delete
        public IActionResult Delete()
        {
            try
            {

                var Employee = JsonConvert.DeserializeObject<SessionVariables>(HttpContext.Session.GetString("LoggedinEmployee"));
                ViewData["Login"] = 1;
                return View();
            }
            catch (Exception e)
            {
                var message = e;
                return RedirectToAction("Login", "Login");
            }
        }

        //POST: Customer/Delete
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete([Bind("Id,CustomerId,CustomerSSNId,Age,Address,Name")] Customer customer)
        {
            if (customer.CustomerSSNId.ToString().Length != 9 || customer.Age > 120 || customer.Age == 0)
            {
                return View();
            }
            else
            {
                var custExist = _context.customers.Any(c => c.CustomerSSNId == customer.CustomerSSNId && c.CustomerId == customer.CustomerId 
                && c.Name == customer.Name && c.Age == customer.Age && c.Address == customer.Address);
                if (custExist)
                {
                    Customer CustToDelete = await _context.customers.FirstOrDefaultAsync(c => c.CustomerSSNId == customer.CustomerSSNId);
                    _context.customers.Remove(CustToDelete);
                    await _context.SaveChangesAsync();
                    TempData["CustomerDeleted"] = "Customer Deleted Successfully";
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    TempData["NoCustomer"] = true;
                    return RedirectToAction(nameof(Create));
                }
            }
        }
        //--------------------------------------------------------------------------------------

        
        //GET: Customer/Update

        public IActionResult Update()
        {
            try
            {
                var Employee = JsonConvert.DeserializeObject<SessionVariables>(HttpContext.Session.GetString("LoggedinEmployee"));
                ViewData["Login"] = 1;
                return View();
            }
            catch (Exception e)
            {
                var message = e;
                return RedirectToAction("Login", "Login");
            }
        }

        //Post: Customer/Update
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Update([Bind("Id, CustomerId")] Customer customer)
        {
            if (customer.CustomerId.ToString().Length != 9)
            {
                return View();
            }
            else
            {
                var custExists = _context.customers.Any(c => c.CustomerId == customer.CustomerId);
                if (custExists)
                {
                    Customer cust = await _context.customers.FirstOrDefaultAsync(c => c.CustomerId == customer.CustomerId);
                    custom = cust;
                    return RedirectToAction(nameof(UpdateConfirmed));
                }
                else
                {
                    TempData["NoCustomer"] = true;
                    return RedirectToAction(nameof(Create));
                }
            }
        }

        //---------Update Customer Second Screen---------------------------------

        //GET: Customer/UpdateConfirmed
        public IActionResult UpdateConfirmed()
        {
            ViewData["Login"] = 1;
            return View(custom);
        }

        //POST: Customer/UpdateConfirmed
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateConfirmed([Bind("Id, CustomerId, CustomerSSNId, CustomerId, Name, Address, Age, State, City")] Customer customer)
        {
            if (customer.Age != 0 && customer.Age < 120)
            {
                Customer cust = new Customer
                {
                    Id = customer.Id,
                    CustomerId = customer.CustomerId,
                    CustomerSSNId = customer.CustomerSSNId,
                    Name = customer.Name,
                    Age = customer.Age,
                    Address = customer.Address,
                    State = customer.State,
                    City = customer.City,
                    status = "Active",
                    Message = "Customer updated successfuly",
                    LastUpdated = DateTime.Now
                };
                _context.Update(cust);
                await _context.SaveChangesAsync();
                TempData["UpdateSuccess"] = "Customer Updated Successfully :)";
                return RedirectToAction("Index", "Home");
            }
            else
            {
                return View();
            }
        }

    }
}
