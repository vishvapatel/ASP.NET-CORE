﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using RetailBanking.Data;
using RetailBanking.Models;

namespace RetailBanking.Controllers
{
    public class LoginController : Controller
    {
        private readonly FedchoiceContext _context;
        public LoginController(FedchoiceContext context)
        {
            _context = context;
                
        }

        //GET:Login/Login
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        //POST:Login/Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login([Bind("Id, EmployeeId, Password")] Login log)
        {
            
            //checking if user exists or not
            var acc = await _context.logins.FirstOrDefaultAsync(a => a.EmployeeId == log.EmployeeId && a.Password == log.Password);
            if (acc != null)
            {

                var Employee = new SessionVariables() { EmployeeId = acc.EmployeeId, Name = acc.Name}; //Creating a session variable object
                
                //Set Session string
                HttpContext.Session.SetString("LoggedinEmployee", JsonConvert.SerializeObject(Employee)); //Initiating a session
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ViewData["Error"] = 1;
                return RedirectToAction("Login");
            }
        }

        [HttpGet]
        public IActionResult Logout()
        {
            //Destroy Session
            HttpContext.Session.Clear();
            return RedirectToAction(nameof(Login));

        }
    }
}
