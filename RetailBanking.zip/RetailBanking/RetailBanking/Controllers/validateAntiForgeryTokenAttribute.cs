﻿using System;

namespace RetailBanking.Controllers
{
    internal class validateAntiForgeryTokenAttribute : Attribute
    {
    }
}