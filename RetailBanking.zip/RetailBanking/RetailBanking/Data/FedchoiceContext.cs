﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using RetailBanking.Models;

namespace RetailBanking.Data
{
    public class FedchoiceContext : DbContext
    {
        public FedchoiceContext(DbContextOptions<FedchoiceContext> options) : base(options)
        {

        }
        public DbSet<Login> logins { get; set; }
        public DbSet<Customer> customers { get; set; }

        public DbSet<Account> accounts { get; set; }

        public DbSet<Transactions> transactions { get; set; }
    }
}
