﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace RetailBanking.Models
{
    public class Account
    {

        public int Id { get; set; }

        [Required]
        [DisplayName("Customer Id")]
        [Range(100000000, 999999999, ErrorMessage="{0} can only be of 9 digits")]
        public int CustomerId { get; set; }

        [Required]
        [DisplayName("Account Id")]
        [Range(100000000, 999999999, ErrorMessage="{0} can only be of 9 digits")]
        public int AccountId { get; set; }

        [Required]
        [DisplayName("Balance")]
        public int balance { get; set;}

        [Required]
        [DisplayName("Type")]
        public string AccountType { get; set; }

        [Required]
        [DisplayName("Message")]
        public string Message { get; set; }

        [DisplayName("Account Status")]
        public string status { get; set; }

        [Required]
        [DisplayName("Last Updated")]
        [DataType(DataType.DateTime)]
        public DateTime LastUpdated { get; set; }
    }
}
