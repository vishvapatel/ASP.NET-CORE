﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace RetailBanking.Models
{
    public class Customer
    {
        public int Id { get; set; }

        [Required]
        [DisplayName("Customer Id")]
        [Range(100000000,999999999,ErrorMessage ="{0} can only be of 9 digits")]
        public int CustomerId { get; set; }

        [Required]
        [DisplayName("Customer SSN Id")]
        [Range(100000000, 999999999, ErrorMessage = "{0} can only be of 9 digits")]
        public int CustomerSSNId { get; set; }

        [Required]
        [DataType(DataType.Text)]
        [StringLength(maximumLength:50, MinimumLength =10, ErrorMessage ="{0} not valid")]
        public string Name { get; set; }

        [Required]
        [Range(1, 120, ErrorMessage ="{0} is not valid")]
        public sbyte Age { get; set; }

        [Required]
        [DataType(DataType.Text)]
        public string Address { get; set; }

        [Required]
        public string State { get; set; }

        [Required]
        public string City { get; set; }

        [Required]
        [DataType(DataType.DateTime)]
        public DateTime LastUpdated { get; set; }

        [Required]
        public string status { get; set; }

        [Required]
        public string Message { get; set; }
    }
}
