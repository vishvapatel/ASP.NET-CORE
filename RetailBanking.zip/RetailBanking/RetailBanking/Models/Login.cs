﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace RetailBanking.Models
{
    public class Login
    {
        public int  Id { get; set; }

        [Required]
        [DisplayName("Employee Id")]
        [StringLength(9, MinimumLength = 9, ErrorMessage = "Employee Id is of 9 Characters")]
        public string EmployeeId { get; set; }

        [Required]
        [DisplayName("Employee Password")]
        [DataType(DataType.Password)]
        [StringLength(9, MinimumLength = 9, ErrorMessage = "Employee Id is of 9 Characters")]
        public string Password { get; set; }

        [StringLength(50,MinimumLength =10)]
        public string Name { get; set; }

    }
}
