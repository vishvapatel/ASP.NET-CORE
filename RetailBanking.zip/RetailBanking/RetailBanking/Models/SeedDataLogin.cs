﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using RetailBanking.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RetailBanking.Models
{
    public class SeedDataLogin
    {
        //This is STRICTLY FOR THE TESTING PURPOSE.
        //Populating the database with this data when it runs.
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new FedchoiceContext(
                serviceProvider.GetRequiredService<DbContextOptions<FedchoiceContext>>()))
            {
                //Look for any data
                if (context.logins.Any())
                {
                    return; //if data exists then no need to seed.
                }
                context.logins.AddRange(

                    new Login
                    {
                        EmployeeId = "201920980",
                        Password = "vp@ICICIB",
                        Name = "Vishva Patel"
                    },
                        
                    new Login
                    {
                        EmployeeId = "201920970",
                        Password ="KL@ICICIB",
                        Name =  "Nakul Upasani"
                    },

                    new Login
                    {
                        EmployeeId = "201920960",
                        Password = "PM@ICICIB",
                        Name = "Priyal Mokaria"
                    }

                    );

                context.SaveChanges();

                
            };

        }
    }
}
