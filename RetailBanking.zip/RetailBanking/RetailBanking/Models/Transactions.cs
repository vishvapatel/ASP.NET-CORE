﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace RetailBanking.Models
{
    public class Transactions
    {
        public int Id { get; set; }

        [Required]
        [DisplayName("Transaction Id")]
        public int TransactionId { get; set; }

        [Required]
        [DisplayName("Source Account Id")]
        public int SrcAccountId { get; set; }

        [Required]
        [DisplayName("Target Account Id")]
        public int TgtAccountId { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime Date { get; set; }

        [Required]
        [DisplayName("Description")]
        public string Discription { get; set; }

        [Required]
        [DisplayName("Amount")]
        public int Amount { get; set; }
    }
}
